/*
 * Copyright (C) 2024-2025 Rem01Gaming
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <AZenith.h>

/**
 * @brief Executes a shell command using a formatted string, mimicking standard system() behavior.
 * @param format Format string for the shell command, followed by variable arguments.
 * @return The exit status code of the command (WEXITSTATUS), or -1 if fork/execution fails.
 */
int systemv(const char* format, ...) {
    char command[MAX_COMMAND_LENGTH];
    va_list args;
    va_start(args, format);
    vsnprintf(command, sizeof(command), format, args);
    va_end(args);

    pid_t pid = fork();
    if (pid == -1) [[clang::unlikely]] {
        log_zenith(LOG_ERROR, "EVENT=SHELL_EXEC_FAILED fn=systemv reason=fork_failed errno=%d", errno);
        return -1;
    }

    if (pid == 0) {
        char* env[] = {MY_PATH, NULL};
        execle("/system/bin/sh", "sh", "-c", command, NULL, env);

        /* If exec fails */
        _exit(127);
    }

    int status;
    if (waitpid(pid, &status, 0) == -1)
        return -1;

    if (WIFEXITED(status))
        return WEXITSTATUS(status);

    return -1;
}
