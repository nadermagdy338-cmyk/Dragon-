@file:Suppress("UnstableApiUsage")

import com.android.build.gradle.internal.api.BaseVariantOutputImpl
import com.android.build.gradle.tasks.PackageAndroidArtifact
import org.jetbrains.kotlin.gradle.dsl.JvmTarget

plugins {
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.agp.app)
    alias(libs.plugins.compose.compiler)
    alias(libs.plugins.ksp)
    id("kotlin-parcelize")
    id("dagger.hilt.android.plugin")
}

/**
 * زمن البناء الذي يُكتب في `BuildConfig.BUILD_TIME` (يُعرض كتاريخ بناء في ترويسة الإعدادات).
 *
 * **لماذا ليس `System.currentTimeMillis()` مباشرةً:** ذاك يتغيّر في كل تشغيل، فيصير
 * `generateReleaseBuildConfig` **غير up-to-date أبدًا** ⇒ كل من يقرأ `BuildConfig` يُعاد
 * تصريفه (٤ ملفات) ⇒ ثم dex ثم R8 ثم التغليف — سلسلة كاملة تُعاد من أجل رقم واحد،
 * و`--build-cache` لا يُصيب منها شيئًا لأن مخرَج المُدخَل يتغيّر في كل بناء.
 *
 * **البديل:** زمن الالتزام — ثابتٌ للنُسخة الواحدة (نفس الالتزام ⇒ نفس الرقم)، فيصير البناء
 * الثاني للنُسخة نفسها شبه مجّاني على الجهاز. وهو أصدق معنًى أيضًا: تاريخ إنتاج النسخة.
 *
 * **والسقوط:** بلا `git` أو بلا التزام (نسخة مفكوكة من zip، أو بناء في AndroidIDE) يُعاد
 * السلوك القديم (ساعة البناء) بدل أن يُرمى خطأ أو يُكتب صفر.
 */
fun buildTimeEpochMs(): Long = runCatching {
    val git = ProcessBuilder("git", "log", "-1", "--format=%ct")
        .directory(rootDir)
        .redirectErrorStream(true)
        .start()
    val seconds = git.inputStream.bufferedReader().use { it.readText() }.trim()
    check(git.waitFor() == 0) { "git log exited with ${git.exitValue()}" }
    val epochSeconds = seconds.toLongOrNull()
    check(epochSeconds != null) { "git log did not return a commit time: '$seconds'" }
    epochSeconds * 1000L
}.getOrElse { System.currentTimeMillis() }

android {
    namespace = "nd.max"
    // API 37 is not published on the GitHub-hosted SDK repository; API 36
    // is the newest stable level available there and satisfies the AAR
    // metadata floor of the current androidx alphas.
    compileSdk = 36

    // كلمة مرور مخزن المفاتيح من سر CI (KS_PWD / KEYSTORE_PASSWORD).
    // بناء release غير موقّع غير صالح كـ priv-app، لذلك نفشل مبكرًا عند طلبه.
    val ksPwd: String? = System.getenv("KS_PWD")
    val releaseArtifactRequested = gradle.startParameter.taskNames.any { requestedTask ->
        requestedTask.substringAfterLast(':') in setOf("assembleRelease", "bundleRelease")
    }
    if (releaseArtifactRequested && ksPwd.isNullOrEmpty()) {
        throw GradleException("KS_PWD must be set to produce a signed release artifact")
    }

    defaultConfig {
        applicationId = "nd.max"
        minSdk = 29
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        vectorDrawables.useSupportLibrary = true
        buildConfigField("long", "BUILD_TIME", "${buildTimeEpochMs()}L")
        ndk {
            // arm64-v8a وحده — قرار المالك (تكملة ٨٢): الأجهزة 32-بت لم تبقَ مدعومة،
            // والمنصّب يرفضها برسالة صريحة بدل تركيب ناقص. الفائدة في البناء: نصف حجم
            // العمل الأصلي، وحزمة أخفّ بما كان مخصّصًا لـ`armeabi-v7a`.
            abiFilters.addAll(listOf("arm64-v8a"))
        }
    }

    tasks.matching { task ->
        task.name in setOf("packageRelease", "assembleRelease", "bundleRelease")
    }.configureEach {
        doFirst {
            check(!ksPwd.isNullOrEmpty()) {
                "KS_PWD must be set to produce a signed release artifact"
            }
        }
    }

    signingConfigs {
        create("release") {
            storeFile = file("azenith.jks")
            if (!ksPwd.isNullOrEmpty()) {
                storePassword = ksPwd
                keyAlias = "azenith_key"
                keyPassword = ksPwd
            }
        }
    }
    
    // ── ملاحظة عن `lintVitalRelease` (قِيست، ولا تُغيَّر هنا) ──
    //
    // `assembleRelease` يستدعي `lintVitalRelease` تلقائيًّا، وقِسناها في هذه البيئة:
    // **٣ دقائق و٢٩ ثانية** من أصل ~١٥ دقيقة (٤ أنوية · ١٥ جيجابايت، نفس مقاس runner).
    //
    // **ولا يُعطَّل هنا:** `checkReleaseBuilds = false` **يمحو المهمة نفسها** (تحقّقنا:
    // اختفت من `:app:tasks --all`)، فيصير الحاجز غائبًا لا منقولًا — وهذا إسقاط لجودة لا
    // تسريع لبناء. الفصل جرى في `.github/workflows/build.yml`: مهمة CI موازية تُشغّل
    // `:app:lintVitalRelease` كما هي، وبناء الحزمة يستثنيها بـ`-x :app:lintVitalRelease`.
    // الحاجز نفسه، وبالتوازي، وبلا مَسّ سلوك البناء المحلي.

    androidResources {
        // [FIX] AGP يرفض الجمع بين توليده الآلي و`android:localeConfig` الصريح في
        // البيان («Locale config generation was requested but user locale config is
        // present in manifest») فيفشل :app:processDebugMainManifest ويسقط البناء كله.
        // نُبقي قائمتنا الصريحة في res/xml/locales_config.xml لأنها المصدر الوحيد
        // الذي يضمن ظهور اللغات الـ85 كاملةً في منتقي النظام — ومنها ما لا يستنتجه
        // التوليد الآلي من أسماء المجلدات (b+sr+Latn، zh-rHK، pt-rPT…) — ولأن
        // tools/i18n_coverage.py --check-codes يتحقق من مطابقتها للمجلدات والمنتقي.
        generateLocaleConfig = false
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            vcsInfo.include = false
            signingConfig =
                if (ksPwd.isNullOrEmpty()) null
                else signingConfigs.getByName("release")
            
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"), 
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
        aidl = true
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/*.version"
            excludes += "DebugProbesKt.bin"
            excludes += "kotlin-tooling-metadata.json"
        }
        // حرس صريح لا يعتمد على دلالات `abiFilters` وحدها: ما تبقّى من ثنائيات 32-بت في
        // المستودع (مثل `kernel-flasher/src/main/jniLibs/armeabi-v7a`) لا يدخل الحزمة.
        // وأثره مُتحقَّق منه في CI: بناء الـAPK يفشل إن وُجد `lib/armeabi-v7a/` داخله.
        jniLibs {
            excludes += "lib/armeabi-v7a/**"
        }
    }

    tasks.withType<PackageAndroidArtifact> {
        doFirst { appMetadata.asFile.orNull?.writeText("") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlin {
        compilerOptions {
            jvmTarget.set(JvmTarget.JVM_17)
        }
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    
    implementation(libs.androidx.compose.material)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.text.google.fonts)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.compose.animation)
    implementation(libs.androidx.compose.animation.core)

    implementation(libs.androidx.navigation.compose)
    
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.material.icons.extended)
    implementation(libs.material.kolor)
    implementation(libs.haze)
    implementation(libs.haze.blur)
    implementation(libs.haze.materials)
    implementation(libs.me.zhanghai.android.appiconloader.coil)
    implementation(libs.io.coil.kt.coil.compose)
    implementation(libs.androidx.documentfile)

    implementation(libs.com.github.topjohnwu.libsu.core)
    implementation(libs.com.github.topjohnwu.libsu.service)
    implementation(libs.com.github.topjohnwu.libsu.io)

    // Shizuku: طبقة امتياز ثانية بمستوى ADB بلا جذر (AR-20).
    // provider ليس اختياريًا: يحمل ShizukuProvider الذي يُصرَّح به في البيان.
    implementation(libs.shizuku.api)
    implementation(libs.shizuku.provider)

    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.lifecycle.service)
    implementation(libs.yalantis.ucrop)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.transition)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.ansi.library)
    implementation(libs.ansi.library.ktx)
    implementation(libs.hiddenapibypass)
    implementation(libs.coil.gif)
    implementation(libs.compose.markdown)

    // Hilt
    implementation("com.google.dagger:hilt-android:2.59.2")
    ksp("com.google.dagger:hilt-compiler:2.59.2")
    implementation("androidx.hilt:hilt-navigation-compose:1.2.0")

    // Terminal (ported from ZKM)
    implementation(project(":terminal-view"))
    implementation(project(":kernel-flasher"))
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)

    // ── الاختبارات الوحدوية ──
    // عقد نصوص التوصيات↔الأفعال (RecommendationTextClassifierTest) —
    // أول خط دفاع ضد انزياح الصياغة بين المصادر والمصنِّف
    testImplementation("junit:junit:4.13.2")
    // Local JVM tests execute against the host JDK, so Android's framework
    // org.json stubs must be replaced by the real JSON implementation.
    testImplementation("org.json:json:20260814")
}
