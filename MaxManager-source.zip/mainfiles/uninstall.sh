#!/system/bin/sh

#
# Copyright (C) 2026-2027 Zexshia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

q() {
    pkill -9 -f "$1"
}

resetprop | awk -F'[][]' '/persist\.sys\.maxmanager/ {print $2}' | while read -r prop; do
    resetprop -p --delete "$prop"
done

for prop in persist.sys.rianixia.learning_enabled persist.sys.rianixia.thermalcore-bigdata.path; do
    resetprop -p --delete "$prop"
done

rm -rf \
    "/data/adb/.config/MaxManager" \
    "/data/MaxManager" \
    "/data/data/nd.max"
: > "/data/adb/modules/MaxManager/remove"

q sys.maxmanager-rianixiathermalcore
q sys.maxmanager-service
q sys.maxmanager-appmonitoring
    
# The app was a priv-app mounted from the module tree: removing the
# module unmounts it, and the package disappears after reboot. Only a
# genuine user-data install (legacy version, the non-overlay fallback, or
# the user-app copy that makes the app visible to root managers) needs an
# explicit uninstall.
#
# والمطابقة بـ`*` حول النمط مقصودة: في «تطبيق نظام مُحدَّث» يحمل `pm path` **مسارين** — أصلًا في
# `/product/priv-app` ونسخة في `/data/app` — والمطابقة على البداية كانت تسقط على أول سطر فقط
# فتترك نسخة البيانات بعد إزالة الوحدة.
case "$(pm path nd.max 2>/dev/null)" in
    *package:/data/app/*) pm uninstall --user 0 nd.max >/dev/null 2>&1 ;;
esac

for dir in "/data/adb/ap/bin" "/data/adb/ksu/bin"; do
    [ -d "$dir/zx" ] && rm -rf "$dir/zx"
done

for dir in "/data/adb/ap/bin" "/data/adb/ksu/bin"; do
    [ -d "$dir" ] && find "$dir" -name "sys.maxmanager-*" -exec rm -f {} +
done

