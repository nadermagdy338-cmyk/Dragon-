# Max Atlas: External Source Assessment

**Task:** ATLAS-R1. **Fetched:** 2026-09-20 UTC. **Scope:** external research only.

This is a source matrix, not a copied device database, dependency manifest, security audit,
legal opinion, or hardware qualification. No upstream scripts, tests, APKs, or daemons were run.
No repository was cloned. Targeted source and documentation were read over HTTPS; repository
metadata and small tree listings were queried through read-only GitHub/Gitiles APIs.

## Evidence Legend

- **F / fetched:** the specified resource was obtained; fetching alone does not validate its claims.
- **R / README-claimed:** a maintainer's documentation makes the claim; execution was not verified.
- **S / source-verified:** the named source implements the described local behavior. This is not proof of all callers, runtime reliability, or hardware safety.
- **N / not inspected:** no implementation-level assertion is supported by this assessment.
- **D / design:** Atlas recommendation, independently authored, not a measured property of an upstream project.

Confidence is claim-specific: HIGH for the observed source branch or official API contract,
MEDIUM for an architectural lesson supported by limited source, LOW for untested compatibility,
performance, device coverage, and uninspected implementation claims. Stars, forks, commit counts,
README test counts, and plausible-looking measurements do not raise the hardware evidence level.

For each GitHub project, metadata was read from `https://api.github.com/repos/OWNER/REPO` and
the default-branch revision from `https://api.github.com/repos/OWNER/REPO/commits/BRANCH`.
Revision below means the observed branch head, not necessarily a released or stable version.
Unless otherwise stated, license is GitHub's detected license plus README attribution; the
full license file, dependency licenses, and history were **not** inspected.

## Required Reference Coverage

| ID | Reference / Exact Upstream | Observed Revision | License Evidence | Inspection And Atlas Disposition |
| --- | --- | --- | --- | --- |
| S01 | [SmartPack-Kernel-Manager](https://github.com/SmartPack/SmartPack-Kernel-Manager) | `c886fc8eae90e74fcc6784813be28feca5b54080`, master; API says archived; commit 2023-03-27 | API GPL-3.0; README and inspected Java headers explicitly v3-or-later | F/R README; S `GPU.java`, `GPUFreq.java`. Valuable domain inventory and per-interface conversion factors, not autonomous proof-discovery. Known paths plus existence checks are not verified write capability. Do not import path maps, scripts, custom controls, or generic governor defaults. |
| S02 | [Calibrate-SoC](https://github.com/mayusi/Calibrate-SoC) | `b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac`, main; 2026-07-03 | API/README Apache-2.0; dependency blanket claims not audited | F/R README; S selected reader, registry and writer files below. Useful access-result separation and a reader abstraction, with important counterexamples. No adoption of vendor bridges, chmod, daemon stopping, write probes, remote presets, or inferred telemetry. ~2,900 tests and real-device claims remain R, not reproduced. |
| S03 | [Kelvin](https://github.com/Anonym0usWork1221/Kelvin) | `3d342c79819d24a82c81e10e9447331610a6478f`, main; 2026-07-28 | API/README and inspected C headers MIT; README separately warns QNN is not covered by MIT | F/R README; S registry, generic, MTK, shared discovery. Reuse the concept of small specialized providers backed by common discovery, not its writer interface or AI studio. Generic requires discovered CPU policy; this is not a guarantee for every Android device. |
| S04 | [FusionHUD](https://github.com/The412Banner/FusionHUD) | `95cb9de030ab302b1efb87cc7e0ac229483b547f`, main; 2026-08-04 | API GPL-3.0; F `ATTRIBUTION.md` adds claimed GPL-3.0 section 7(b) author attribution in documentation AND in-app credits | F/R README; S selected `HudMetrics.java` methods. Good resolved-source/cached-candidate/diagnostic pattern. Reject magnitude-only unit inference and frequency-as-CPU-load substitution as measured telemetry. It is an in-host-app View overlay, not a universal cross-app GPU timing layer. |
| S05 | [ApexTuner](https://github.com/skysyaz/apextuner) | `218bbe89346c3548f1fcd7bcc219efb58111ec25`, main; 2026-07-12 | API license **null**; README says `MIT. See LICENSE (to be added)`; no complete grant established here | F/R pinned README; N implementation. Transaction/rollback, runtime probing and supported-device lists are documentation claims, not demonstrated proof. README says native module is a Kotlin-only stub. Retain architectural reference only, no dependency recommendation. |
| S06 | [Advanced Charging Controller / ACC](https://github.com/VR-25/acc) | `908a5a4b716b7f2506a2e1426429293a11f42ab3`, **dev**; 2025-06-06 | API GPL-3.0; pinned README explicitly v3-or-later | F/R master README initially, then pinned dev README/config and S dev switch routines. Strong lesson in invalidation and reasoned failure, but switch testing actively turns charging off/on and can trigger documented failures. Never call it for Atlas discovery. Exact retry claim is qualified below. |
| S07 | [AutoSystemBoost](https://github.com/krilikd-factory/AutoSystemBoost) | `031f1b097adb38e86551ec2ef7a275e02130d9ab`, main; 2026-09-19 | API MIT; full license not inspected | F/R pinned README; N implementation. README explicitly scopes support to rooted OnePlus, describes peer-checked `socd`, fallback, periodic recovery, dwell and source confidence. Use as a test-design hypothesis, not universal thermal classification or permission to alter safety thresholds. |
| S08 | [Thrawl](https://github.com/Fawrz/Thrawl) | `47a10d5c03633a42d98016b1aad31695ecb6ab5a`, main; 2026-08-14 | API/README MIT | F/R pinned README; N implementation. PSI `some avg60` versus meminfo heuristic are different signals, not interchangeable measurements. README says max-swappiness detection tries values the kernel accepts, so do not assume it is read-only. Its 37 tests and Android coverage were not run. Unfiltered logcat warning is a privacy counterexample. |
| S09 | [PerfMTK](https://github.com/JUANIMAN/PerfMTK) | `e7e4c268be82ee51d4a5df39fe99c65f67dbaa3d`, main; 2026-09-19 | API/README GPL-3.0 | F/R targeted pinned README; N implementation. MTK/Mali, topology, FPSGO, UFS and foreground-service features are useful provider-domain pointers. Advertises thermal-disable and bypass options: excluded. Sub-ms switching, 0.0% idle CPU, 120 FPS and broad OEM support are unverified marketing/README claims. No path/profile import. |
| S10 | [AZenith](https://github.com/Liliya2727/AZenith) | `77fe9f75ab3d4316621a75f1f162eabfc8e9cc64`, main; 2026-09-08 | API/README Apache-2.0 | F/R targeted pinned README confirms auto profiles, CPU limiter and Thermalcore descriptions; N backend/boot code. Rust, anti-bootloop, semi-event-driven behavior and all historical counts in txt.txt were not independently inspected. Policy/boot patterns are outside this phase, not Atlas requirements. |
| S11 | [MAGNETAR](https://github.com/Kyliekyler/MAGNETAR) | `6c41744c7cf953faecf8906704a84d962a9d2b97`, release; 2025-08-30 | API `NOASSERTION`; **F actual `LICENSE`** declares CC BY-NC-ND 4.0, agreeing with README | Identity was absent from txt.txt's URL list; search found this strong title/description match. F/R README; N ML implementation. Adaptive behavior is claimed, not verified ML effectiveness. README says bug reports are automatically routed to a channel: not Atlas's local consented flow. No code/content import. |
| S12 | [OdinTools](https://github.com/langerhans/OdinTools) | `0eaf49392e263bf1de4d6c7eb37aeb03dadb0ccc`, main; 2024-05-25 | API MIT; license body not inspected | F/R relevant pinned README: foreground-app overrides for controller/trigger/performance/fan modes applied and reverted. N state-machine implementation and specific `High Performance + Fan Off` constraint from txt.txt. Useful lifecycle analogy; no new per-app controller is needed for Atlas. |
| S13 | [GameMode](https://github.com/FeralInteractive/gamemode) | `a74b8106a2236d1f2696aa44c93bc4c8ef13b42e`, master; 2026-06-15 | API/README BSD-3-Clause; README lists inih separately | txt.txt has no URL; official project matches described daemon/lib design. F/R targeted pinned README; N daemon internals. Supports temporary optimization requests and separate client/daemon boundary. Linux/systemd architecture is not an Android transport or proof of rollback under every crash. |
| S14 | [auto-cpufreq](https://github.com/AdnanHodzic/auto-cpufreq) | `64557fb388a40b51cdc5c908d5fce20f7ca94e17`, master; 2026-09-12 | API GPL-3.0; full license not inspected | txt.txt has no URL; official project matches. F/R pinned README including Monitor/Live sections; N implementation. Monitor promises no changes; Live makes temporary changes lost at reboot. Preserve observation/application separation, not its Linux service/install scripts or policy. |
| S15 | [Android Dynamic Performance Framework / ADPF](https://developer.android.com/games/optimize/adpf) | Developer guides timed out; official AOSP framework source observed at `1cdfff555f4a21f71ccc978290e2e212e2f8b168`; Android 11 tag also inspected | Inspected AOSP framework source is Apache-2.0; website/sample/dependency terms not blanket-cleared | F/S official public API Javadocs and implementations via AOSP, below. Performance hints concern the calling app's threads; not unrestricted cross-app tuning. PowerManager headroom/status are observations, not GPU/CPU setters. API/device availability and NaN must be handled. |
| S16 | [Unity Adaptive Performance](https://docs.unity3d.com/Packages/com.unity.adaptiveperformance@5.1/manual/index.html) | Official package docs **5.1.6** fetched; not asserted latest; package implementation not fetched | Unity website terms apply; package license not inspected, **unknown for reuse** | F official overview and provider guide; N package source. Ordered loaders, start/stop/init/deinit and nullable active provider are documented. Architectural analogy only; no Unity package/runtime added to Android app. Loader success is not proof of every capability or other-app authority. |
| S17 | [Kprofiles](https://github.com/beakthoven/Kprofiles) | `82441dbf8131527c90048f46be58ae9cdb463df3`, main; 2025-03-24 | API/README GPL-2.0; only/or-later detail not established | txt.txt has no URL; kernel-module project matches API and modes. F/R pinned README; N kernel implementation. Disabled/Battery/Balanced/Performance and screen-off notifier documented. Requires kernel integration; node presence does not establish what a vendor kernel makes each mode do. Observe only unless an existing reviewed backend already has that contract. |

### Additional Mention: Universal Smart Governor

**S18:** [cyaniket999/Universal-Smart-governor](https://github.com/cyaniket999/Universal-Smart-governor),
`11cb646980ed01ac00c9dafcbebd876a6551c9da`, main, 2026-07-19. API and README say MIT;
full license not inspected. **F/R pinned README; N executable implementation.** This is a
strong name/behavior match for the URL-less mention, not certainty about the prose author's
intended revision. README advertises forcing thermal cooling states to zero, removing thermal
boundaries and raising permissions, and warns of bootloops/heat. Classify as a **negative safety
reference**, not a source of approved paths, compatibility guarantees, or benchmarks. A permissive
license cannot authorize unsafe behavior.

## Central Source Semantics

### S01: SmartPack

- F/S [GPU.java](https://github.com/SmartPack/SmartPack-Kernel-Manager/blob/c886fc8eae90e74fcc6784813be28feca5b54080/app/src/main/java/com/smartpack/kernelmanager/utils/kernel/gpu/GPU.java): `supported()` aggregates individual feature support. This supports per-feature degradation rather than one model-level supported flag.
- F/S [GPUFreq.java](https://github.com/SmartPack/SmartPack-Kernel-Manager/blob/c886fc8eae90e74fcc6784813be28feca5b54080/app/src/main/java/com/smartpack/kernelmanager/utils/kernel/gpu/GPUFreq.java): stores named path/conversion maps, selects existing entries, caches selections and routes setters to `Control.runSetting`. The constructor falls back to a fixed governor list if no list is read. `hasGovernor`/`hasMaxFreq` are presence-based, not verified effect. The per-path divisors demonstrate why units belong to an interface contract; they do not establish those vendor ABIs today.
- F/R [README](https://github.com/SmartPack/SmartPack-Kernel-Manager/blob/c886fc8eae90e74fcc6784813be28feca5b54080/README.md): custom controller, shell script manager and requests for sysfs path/content/apply details are documented. Those are a maintenance workflow analogy, not authorization for arbitrary runtime controls. The universal-compatibility wording is not a hardware proof.

### S02: Calibrate-SoC

- F/S [WriterRegistry.kt](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/app/src/main/java/io/github/mayusi/calibratesoc/data/tunables/writer/WriterRegistry.kt): routing is **per tunable family**, with PServer/vendor carve-outs, ROOT before SHIZUKU, direct-unlocked and Noop cases. The simple `Vendor -> Shizuku -> Root -> Script -> Read-only` prose is not the actual universal ordering.
- F/S [SysfsProber.kt](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/app/src/main/java/io/github/mayusi/calibratesoc/data/capability/SysfsProber.kt): read enumeration is separate from a documented Shizuku no-op write probe. CPU policies use `related_cpus` and discovered frequency data; GPU lookup has alternatives. However, `readPolicy` replaces unreadable current caps with table bounds/zero, Adreno does similar substitution, many I/O errors become null, and temperature normalization uses magnitude. Atlas must not inherit those semantics.
- F/S [WriteProtocol.kt](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/app/src/main/java/io/github/mayusi/calibratesoc/data/tunables/writer/WriteProtocol.kt) and [RootWriter.kt](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/app/src/main/java/io/github/mayusi/calibratesoc/data/tunables/writer/RootWriter.kt): actual code can stop services and chmod nodes. `executeProtocol` reads previous state, writes, then returns `Success` from shell success without a post-write value read; post-hook/seal failures are logged rather than changing that result. Therefore **do not repeat a claim that every writer itself proves readback**. Some other paths may verify; the entire project was not audited.
- F/S [TunableWriter.kt](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/app/src/main/java/io/github/mayusi/calibratesoc/data/tunables/TunableWriter.kt): `write` journals previous value then dispatches; it does not add universal readback to RootWriter. `revertAll` walks the journal, with success/skip distinctions that need their own audit. This is partial source evidence for journaling, not a complete atomic transaction guarantee.
- F/R [README](https://github.com/mayusi/Calibrate-SoC/blob/b7f6b93d66dee1a2dd9dec581feefc7ba47a0bac/README.md): ~2,900 tests, alpha status, thermal/non-interference protections and device EACCES-versus-vendor success anecdotes remain maintainer claims. The source tree contains test files, but neither assertion count nor passing status was established. Do not convert source file counts into test counts.

### S03: Kelvin

- F/S [registry.c](https://github.com/Anonym0usWork1221/Kelvin/blob/3d342c79819d24a82c81e10e9447331610a6478f/daemon/soc/registry.c): first matching provider wins, in qcom, mediatek, exynos, generic order.
- F/S [generic.c](https://github.com/Anonym0usWork1221/Kelvin/blob/3d342c79819d24a82c81e10e9447331610a6478f/daemon/soc/generic.c): generic probe requires at least one detected CPU policy. Its provider contains **writers**, not just discovery; Atlas's seam must be narrower.
- F/S [socutil.c](https://github.com/Anonym0usWork1221/Kelvin/blob/3d342c79819d24a82c81e10e9447331610a6478f/daemon/soc/socutil.c): CPU discovery probes `policy0..15`; thermal discovery has a 96-zone index bound; GPU discovery uses token matches then first successful candidate. These are bounded implementation choices, not Linux guarantees or sufficient semantic identity. Prefer bounded actual directory enumeration and ambiguity handling in Atlas.
- F/S [mtk.c](https://github.com/Anonym0usWork1221/Kelvin/blob/3d342c79819d24a82c81e10e9447331610a6478f/daemon/soc/mtk.c): detects PPM user-limit nodes and writes them; restore writes `-1`. Comments refuse thermal table/PPM-disable/debug-NPU/chmod approaches. **The claim that PPM syntax and `-1` are documented/reversible for every target kernel was not independently verified against vendor kernel source.** Never generalize it into a new writer.

### S04: FusionHUD

- F/S [HudMetrics.java](https://github.com/The412Banner/FusionHUD/blob/95cb9de030ab302b1efb87cc7e0ac229483b547f/fusionhud/src/main/java/com/winlator/star/widget/HudMetrics.java): `discoverGpuUsagePaths`, `discoverGpuClockPaths`, `prioritizePaths` and `discoverAllThermalZones` confirm static plus dynamic candidates, token ranking and caches; `snapshot` centralizes collection; `buildDiagnosticsReport` reports hits/misses.
- S `getGpuClockMhz` (around lines 870-881) infers Hz/kHz/MHz by magnitude; `getCpuUsagePercent` and `readPerCorePercent` can use frequency/max-frequency as a load proxy. These are heuristics, not measured utilization. Thermal first-plausible-path selection is not proof of sensor identity. Cache existence is source-verified; robust invalidation on all kernel/privilege/runtime changes is **not** established.
- F [ATTRIBUTION.md](https://github.com/The412Banner/FusionHUD/blob/95cb9de030ab302b1efb87cc7e0ac229483b547f/ATTRIBUTION.md) supplies supplemental attribution terms omitted by the API's coarse GPL label. This research does not decide enforceability or downstream license compatibility.

### S06: ACC

- F/S [install/acc.sh](https://github.com/VR-25/acc/blob/908a5a4b716b7f2506a2e1426429293a11f42ab3/install/acc.sh), `test_charging_switch_` (127 onward), and [install/misc-functions.sh](https://github.com/VR-25/acc/blob/908a5a4b716b7f2506a2e1426429293a11f42ab3/install/misc-functions.sh), `flip_sw` (278 onward): switch tests invoke off/on; `flip_sw` calls `write`. Even rewriting an existing value is not a read-only probe.
- F/S [install/accd.sh](https://github.com/VR-25/acc/blob/908a5a4b716b7f2506a2e1426429293a11f42ab3/install/accd.sh): `unsolicitedResumes` initializes to zero (501), resets on non-charging (136), checks `>=3` before increment (143-152). On that uninterrupted qualified branch, the fourth observation reaches invalidation; this is not a generic three-failed-I/O rule. `disable_charging` handles a direct failure differently. This is a static branch trace, **not an executed upstream test**.
- F/R [pinned README](https://github.com/VR-25/acc/blob/908a5a4b716b7f2506a2e1426429293a11f42ab3/README.md) and [default-config.txt](https://github.com/VR-25/acc/blob/908a5a4b716b7f2506a2e1426429293a11f42ab3/install/default-config.txt) say three consecutive failures and document PMIC/charging/bootloop risks. The default GitHub branch is dev, not master; do not mix branches when reproducing these findings.

## Official Platform Sources

| ID | Exact Source / Revision | Verified Contract And Limit |
| --- | --- | --- |
| L01 | [Linux sysfs](https://docs.kernel.org/filesystems/sysfs.html), live docs advertised 7.3.0-rc3 when fetched; page revision note 2011 | F official docs: attributes call driver `show`/`store`; I/O can fail and represented hardware can disappear. Class directories contain symlinks. A file is an ABI, not ordinary inert data. No universal safe-read/write inference from its name/mode. |
| L02 | [CPU performance scaling](https://docs.kernel.org/admin-guide/pm/cpufreq.html), same live documentation snapshot | F official docs: policyX groups shared hardware control; `related_cpus` includes offline CPUs, `affected_cpus` online CPUs. Frequency attributes are kHz. `scaling_cur_freq` often last requested P-state, not exact hardware frequency. Tables may be absent for continuous ranges. |
| L03 | [devfreq ABI](https://docs.kernel.org/admin-guide/abi-testing.html), `/sys/class/devfreq/...` section | F official ABI: available frequencies are a snapshot, not min/max-constrained; `cur_freq` can equal target when driver lacks `get_cur_freq`; min/max value zero means no user restriction. Initial raw docs URLs failed (404/429); this rendered page was read instead. The page is large; only devfreq/thermal entries informed this assessment. |
| L04 | [devfreq.c, Linux v6.12](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/v6.12/drivers/devfreq/devfreq.c), especially min/max store conversion | F/S: sysfs frequency values converted using `HZ_PER_KHZ` for PM QoS; max example converts 666666666 Hz to rounded kHz, zero means no limit. Establishes mainline Hz semantics, **not vendor forks**. |
| L05 | [Thermal sysfs driver](https://docs.kernel.org/driver-api/thermal/sysfs-api.html) and [thermal ABI v6.12](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/v6.12/Documentation/ABI/testing/sysfs-class-thermal) | F official docs: `type` is driver-supplied; zone `temp` is millidegrees C. Cooling devices can be processor/fan/etc.; cur_state is a cooling state, not temperature. Emulation/mode/trip changes are mutations. Neither zone index nor generic `tsens` proves CPU/GPU/battery location. |
| L06 | [Power-supply class v6.12](https://kernel.googlesource.com/pub/scm/linux/kernel/git/torvalds/linux/+/v6.12/Documentation/power/power_supply_class.rst) | F official docs: microvolts, microamps, microamp-hours, microwatt-hours, seconds, tenths of degree C unless otherwise stated. Energy and charge are different dimensions; battery temperature and thermal-zone temperature have different scales. |
| A01 | [PerformanceHintManager.java](https://android.googlesource.com/platform/frameworks/base/+/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/os/PerformanceHintManager.java) | F/S official source/Javadoc: application threads, nullable unsupported session; setThreads requires app thread group and can throw SecurityException. Hints do not grant other-app ownership or sysfs rights. Main endpoint and revision metadata read in same research; Java API version support must remain SDK-gated. |
| A02 | [PowerManager.java](https://android.googlesource.com/platform/frameworks/base/+/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/os/PowerManager.java) and [Android 11 version](https://android.googlesource.com/platform/frameworks/base/+/android-11.0.0_r1/core/java/android/os/PowerManager.java) | F/S: headroom is forecast/estimate of envelope use, slow-sensor-oriented; 1.0 means SEVERE, values can exceed 1, NaN means unavailable/rate limited, forecast 0..60 seconds. During warmup current value may be returned instead of forecast. Inspected Javadocs describe about one second; use a conservative shared 10-second design cadence, not an invented universal 10-second API law. |
| A03 | [HardwarePropertiesManager.java](https://android.googlesource.com/platform/frameworks/base/+/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/os/HardwarePropertiesManager.java) | F/S official Javadocs: temperatures, CPU usage and fan speeds restricted to device owner/current VR service; unsupported may be empty. Being able to reference the public class is not general sensor access. |
| A04 | [AOSP app_neverallows.te](https://android.googlesource.com/platform/system/sepolicy/+/refs/heads/main/private/app_neverallows.te), main fetched, immutable revision not captured | F/S: untrusted apps denied sysfs writes, default sysfs-label access and several proc/cgroup accesses. This is upstream policy, not a measurement of an OEM/root-manager SELinux domain. No chmod/SELinux workaround is proposed. |
| A05 | [AndroidX FileProvider.java](https://android.googlesource.com/platform/frameworks/support/+/androidx-main/core/core/src/main/java/androidx/core/content/FileProvider.java), androidx-main fetched, immutable revision not captured | F/S official Javadocs/source: content URIs, configured private subdirectories, temporary grants; requires non-exported provider with grantUriPermissions. Atlas should give only read permission for one sanitized report, not the broad example's optional write permission. Source Apache-2.0; reuse existing project dependency, no upgrade requested. |
| U01 | [Unity provider guide 5.1.6](https://docs.unity3d.com/Packages/com.unity.adaptiveperformance@5.1/manual/provider.html) | F official docs: loader lifecycle and ordered first successful loader, null if none. Useful seam analogy, but Atlas should resolve per capability so one vendor miss does not suppress a generic feature. |
| O01 | [OWASP MASVS](https://mas.owasp.org/MASVS/), live unpinned site | F official taxonomy: STORAGE, PLATFORM, CODE, PRIVACY and authorization concerns relevant to mobile support-report/discovery design. Not an audit, certification, or a claim to satisfy every control. |

Linux documentation/source licensing varies by file and applicable notices; this research uses
citations and independently written explanations only. Do not infer a license grant for copied
driver code from the Linux project name. Android developer/source site guides timed out here;
the specific source/Javadoc contracts above are the verified fallback, not a claim that the
latest web guide was inspected. No Context7/MCP lookup tool was available; no package was
installed to obtain one.

## Batch 2 — Gap-Review Sources (2026-09-20)

These were read in a second research round whose analysis lives in
[`01-GAPS-AND-IDEAS.md`](./01-GAPS-AND-IDEAS.md) §3–§5. This table is an **index only**; the
claim-level analysis (what each source establishes, its limit, and its disposition) is kept in that
one document so the two cannot drift apart.

| ID | Exact Source / Revision Captured | Why It Was Fetched |
| --- | --- | --- |
| S18a | AOSP `platform/system/sepolicy`, `private/app.te`, `refs/heads/main`, blob `3219fbe9623f4b0a6a68da525534cbb85ee39cd3` | The explicit allow-list for app domains: `sysfs_gpu` read is granted; `proc_meminfo` is granted **and marked for removal**; `sysfs_devices_system_cpu` and `proc_cpuinfo` are domain-wide |
| S18b | same repo, `private/app_neverallows.te`, blob `434fb132e7adb545dc511564ca3b631ec617115a` | The deny-list that rules out `/proc/stat`, `/proc/uptime`, `/proc/version`, `/proc/vmstat`, `/proc/loadavg`, `/proc/mounts`, `/proc/swaps`, cgroup v1/v2 files, debugfs reads, `selinuxfs`, `sysfs_net`, uevent netlink, `proc_uid_*` |
| S18c | same repo, `private/domain.te`, blob `6999586eaf09978949b1ab3fce5bba738870c47a` | `r_dir_file(domain, sysfs_devices_system_cpu)` and `allow domain proc_cpuinfo:file r_file_perms;` — i.e. CPU surfaces are granted broadly, while `cgroup`/`debugfs`/`selinuxfs` are search-only |
| S19 | AOSP `device/google/gs201`, `powerhint.json`, commit `a1deb18`, blob `131af2098740f22438f777a27c848ca60e474cdb` | An upstream **per-device node catalog** (`Name`/`Path`/`Values`, `ResetOnInit`, `Type: "Property"`) that also proves many of these nodes are Power HAL **write** surfaces and that one logical interface sits at different paths per SoC |
| S20 | Chromium `src/gpu/config/gpu_driver_bug_list.json`, `refs/heads/main`, blob `b6c228eaa074f0122baec1510617eba50f48aef0` | A mature per-driver exception database: `id`, `description`, `cr_bugs`, matching on GL vendor/renderer/version and driver version, `features`/`disabled_extensions`, and an `exceptions` escape hatch |
| S21 | libinput device-quirks documentation (1.31) and `90-libinput-model-quirks.hwdb` | Plain-text, independently updatable quirk storage with a diagnosis tool — the maintainability pattern for a quirk base |
| S22 | `saschabrunner/Android-Thermal-Monitor` (README) | Independent statement that thermal sysfs access is device-dependent: some devices deny it without root, some never expose it |
| S23 | `google/battery-historian` (README, analyzer) | Precedent for turning a device report into an analysis pipeline — the shape a report-to-fixture tool would take |
| S24 | Linux UFS health descriptor ABI (`life_time_a/b`, `pre_eol_info`) and its LKML patch series | A read-only storage-health surface that may exist but is permission/label dependent |
| S25 | Linux `Documentation/ABI/testing/sysfs-class-powercap` (`energy_uj`), observed via `android.googlesource.com/kernel/common` at `d4504d1eba95` | Energy counters exist in the kernel, but no evidence was found that an unprivileged Android app may read them — recorded as conditional, not adopted |
| A06 | `android.os.Build.SOC_MANUFACTURER` / `SOC_MODEL` (API 31) plus `get_prop(domain, soc_prop)` | SoC identity from a public surface, which is what `vendorHints()` needs |
| A07 | Android 14 battery-health APIs in `BatteryManager` (cycle count, charging status, state of health) | A public replacement for vendor battery nodes |
| A08 | AOSP *Thermal mitigation* (source.android.com, fetched 2026-09-20) | App-facing thermal truth is `PowerManager` status codes; detailed sensors and cooling devices go to **trusted** clients only; the thermal HAL is the authoritative throttling reporter |
| A09 | Google Issue Tracker 37140047 (title and snippet only; the page is script-rendered) | Independent confirmation that Android O removed app access to `/proc/stat` through SELinux |
| A10 | ADPF `PerformanceHintManager` and the Android *Thermal API* pages | The public interfaces that actually exist for performance/thermal observation |

**Batch-2 licence status:** no licence file was opened for any source above, and **no code, path table,
script, quirk list or profile was imported** from them. They are architectural and policy references
only. Reproduce any row by reading its immutable `blob/REV/PATH` URL.

**Batch-2 open question:** no `allow` and no `neverallow` was found for `/proc/pressure` in the policy
files read here, so its availability to an app is **not settled** by these sources — the existing
`MemoryStall.kt` reader is not evidence of platform support. Measure it per `01-GAPS-AND-IDEAS.md` §8.

## Unresolved Claims And Reproduction Notes

- README statements about test counts, device results, ML gains, sensor correctness, thermal safety and benchmark improvements remain unverified unless the specific behavior above is marked S. None is hardware proof.
- For projects without an explicit txt.txt URL (MAGNETAR, GameMode, auto-cpufreq, Kprofiles, Universal Smart Governor), the selected identity is documented, not silently assumed to be the original author's exact source/revision.
- A bounded source inspection cannot establish absence of vulnerabilities, complete rollback, truthful UI in all states, or license compatibility. Especially do not mistake Apache/MIT root metadata for a dependency audit.
- Reproduce a source observation by reading its immutable `blob/REV/PATH` or Gitiles `+/REV/PATH?format=TEXT` URL. Decode Gitiles base64 as data only. No build/install/test invocation is needed or authorized for this research.
- Initial GitHub metadata command expected `jq`, which is not installed; it was replaced by Python's standard-library HTTP/JSON parsing. No local files or external executable code were involved in that fallback.
- Prefer the pinned URLs above for subsequent planning; recheck moving docs and branch heads before implementation. No upstream database or source excerpt has been embedded as executable/product data in this repository.
